# tbot_bot/screeners/screener_utils.py
# Utility functions for universe cache and credential management, atomic append helpers, and atomic load/save for universe/build outputs.

import json
import logging
import os
from datetime import datetime, timezone
from typing import List, Dict, Optional
import requests  # <<< ADDED

from tbot_bot.support.path_resolver import (
    resolve_universe_cache_path,
    resolve_universe_partial_path,
    resolve_universe_unfiltered_path,
    resolve_screener_blocklist_path
)
from tbot_bot.support.secrets_manager import (
    load_screener_credentials,
    screener_creds_exist as _sm_screener_creds_exist,
)
from tbot_bot.screeners.screener_filter import (
    normalize_symbols, dedupe_symbols
)
from tbot_bot.screeners.blocklist_manager import load_blocklist as load_blocklist_full

LOG = logging.getLogger(__name__)

SCHEMA_VERSION = "1.0.0"
UNFILTERED_PATH = resolve_universe_unfiltered_path()
BLOCKLIST_PATH = resolve_screener_blocklist_path()

class UniverseCacheError(Exception):
    pass

def atomic_append_json(path: str, obj: dict):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Write newline-delimited JSON object per spec
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def atomic_append_text(path: str, line: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(line if line.endswith("\n") else line + "\n")

def atomic_copy_file(src_path: str, dest_path: str):
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    tmp_path = dest_path + ".tmp"
    with open(src_path, "rb") as src, open(tmp_path, "wb") as dst:
        while True:
            chunk = src.read(1048576)
            if not chunk:
                break
            dst.write(chunk)
        dst.flush()
        os.fsync(dst.fileno())
    os.replace(tmp_path, dest_path)

def screener_creds_exist() -> bool:
    """
    True only when at least one indexed provider (PROVIDER_XX) exists.
    """
    return _sm_screener_creds_exist()

def get_screener_secrets() -> dict:
    """
    Return the flat generic credentials dict (e.g., PROVIDER_01, SCREENER_API_KEY_01, ...).
    Never raises; returns {} if no file/providers present. Universe gating happens in callers.
    """
    try:
        if not _sm_screener_creds_exist():
            return {}
        return load_screener_credentials()
    except Exception as e:
        LOG.error(f"[screener_utils] Failed to load screener secrets: {e}")
        return {}

def get_universe_screener_secrets() -> Dict[str, Dict]:
    """
    Returns a dict of provider configs keyed by provider name (e.g., 'FINNHUB'),
    including only providers with UNIVERSE_ENABLED='true'. Provider-scoped fields
    have their index suffix stripped, e.g., 'SCREENER_API_KEY_01' -> 'SCREENER_API_KEY'.

    Raises:
        UniverseCacheError: if no enabled providers are found after parsing.
    """
    def _truthy(v) -> bool:
        return str(v).strip().lower() in ("1", "true", "yes", "y", "on")

    secrets = get_screener_secrets()
    result: Dict[str, Dict] = {}

    # Identify provider indices from keys like 'PROVIDER_01' -> 'FINNHUB'
    for k, v in secrets.items():
        if not k.startswith("PROVIDER_"):
            continue
        idx = k.split("_")[-1]
        provider_name = str(v).strip().upper() if v else ""
        if not provider_name:
            continue

        enabled = secrets.get(f"UNIVERSE_ENABLED_{idx}", "false")
        if not _truthy(enabled):
            continue

        # Collect all fields for this index, removing the "_{idx}" suffix
        provider_cfg: Dict[str, str] = {"SCREENER_NAME": provider_name, "PROVIDER": provider_name}
        suffix = f"_{idx}"
        for kk, vv in secrets.items():
            if kk.endswith(suffix):
                base = kk[: -len(suffix)]
                provider_cfg[base] = vv
        result[provider_name] = provider_cfg

    if not result:
        raise UniverseCacheError("No screener providers enabled for universe operations. Enable at least one provider (UNIVERSE_ENABLED=true).")

    return result

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# ADDED: single-source realtime price helper using Screener Credentials
def get_realtime_price(symbol: str, timeout: int = 4) -> float:
    """
    Single source of truth for market prices.
    Uses the currently enabled Screener Credentials (prefers FINNHUB).
    """
    providers = get_universe_screener_secrets()  # uses the same credentials store/UI
    # Prefer FINNHUB if multiple providers are enabled
    if "FINNHUB" in providers:
        provider = "FINNHUB"
    else:
        # take the first enabled provider if any
        provider = next(iter(providers.keys()))

    cfg = providers[provider]

    if provider == "FINNHUB":
        token = (
            cfg.get("SCREENER_API_KEY")
            or cfg.get("API_KEY")
            or cfg.get("FINNHUB_API_KEY")
            or cfg.get("TOKEN")
        )
        if not token:
            raise UniverseCacheError("FINNHUB API key missing in Screener Credentials.")
        r = requests.get(
            "https://finnhub.io/api/v1/quote",
            params={"symbol": symbol, "token": token},
            timeout=timeout,
        )
        r.raise_for_status()
        data = r.json() or {}
        px = data.get("c")
        if px is None:
            raise UniverseCacheError(f"FINNHUB returned no price for {symbol}: {data}")
        return float(px)

    raise UniverseCacheError(f"Market-data provider '{provider}' not supported for quotes.")
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

def utc_now() -> datetime:
    return datetime.utcnow().replace(tzinfo=timezone.utc)

def load_universe_cache(bot_identity: Optional[str] = None) -> List[Dict]:
    if not screener_creds_exist():
        raise UniverseCacheError("Screener credentials not configured. Please configure screener credentials in the UI before running screener operations.")
    path = resolve_universe_cache_path(bot_identity)
    if not os.path.exists(path):
        LOG.error(f"[screener_utils] Universe cache missing at path: {path}")
        raise UniverseCacheError(f"Universe cache file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        symbols = []
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
                symbols.append(record)
            except Exception as e:
                raise UniverseCacheError(f"Failed to parse line in universe cache: {e}")
    if len(symbols) < 10:
        raise UniverseCacheError("Universe cache is a placeholder/too small; trigger rebuild.")
    for s in symbols:
        if not all(k in s for k in ("symbol", "exchange", "lastClose", "marketCap")):
            raise UniverseCacheError(f"Symbol entry missing required fields: {s}")
    LOG.info(f"[screener_utils] Loaded universe cache with {len(symbols)} symbols from {path}")
    return symbols

def load_partial_cache() -> List[Dict]:
    path = resolve_universe_partial_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]
    except Exception:
        return []

def load_unfiltered_cache() -> List[Dict]:
    path = UNFILTERED_PATH
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]
    except Exception:
        return []

def save_universe_cache(symbols: List[Dict], bot_identity: Optional[str] = None) -> None:
    path = resolve_universe_cache_path(bot_identity)
    tmp_path = f"{path}.tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            for s in symbols:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception as e:
        LOG.error(f"[screener_utils] Failed to write universe cache to disk: {e}")
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise
    LOG.info(f"[screener_utils] Universe cache saved with {len(symbols)} symbols at {path}")

def load_blocklist(path: Optional[str] = None) -> List[str]:
    if not path:
        blockset = load_blocklist_full()
        return list(blockset)
    if not os.path.isfile(path):
        LOG.warning(f"[screener_utils] Blocklist file not found or not provided: {path}")
        return []
    blocklist = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                sym = line.split("|", 1)[0].upper()
                blocklist.append(sym)
    except Exception as e:
        LOG.error(f"[screener_utils] Failed to load blocklist file '{path}': {e}")
        return []
    LOG.info(f"[screener_utils] Loaded blocklist with {len(blocklist)} tickers from {path}")
    return blocklist

def is_cache_stale(bot_identity: Optional[str] = None) -> bool:
    try:
        _ = load_universe_cache(bot_identity)
        return False
    except UniverseCacheError:
        return True

def get_cache_build_time(bot_identity: Optional[str] = None) -> Optional[datetime]:
    path = resolve_universe_cache_path(bot_identity)
    if not os.path.exists(path):
        return None
    try:
        return datetime.fromtimestamp(os.path.getmtime(path), tz=timezone.utc)
    except Exception:
        return None

def get_symbol_set(bot_identity: Optional[str] = None) -> set:
    try:
        symbols = load_universe_cache(bot_identity)
        return set(s.get("symbol") for s in symbols if "symbol" in s)
    except UniverseCacheError:
        return set()
