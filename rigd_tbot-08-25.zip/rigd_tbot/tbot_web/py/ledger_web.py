# tbot_web/py/ledger_web.py

import csv
import io
import traceback
import sqlite3
from pathlib import Path
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify

from tbot_bot.support.decrypt_secrets import load_bot_identity
from tbot_bot.support.path_resolver import (
    validate_bot_identity,
    get_bot_identity_string_regex,
    resolve_ledger_db_path,
)
from tbot_web.support.auth_web import get_current_user
from tbot_bot.config.env_bot import get_bot_config
from tbot_web.support.utils_coa_web import load_coa_metadata_and_accounts

from tbot_bot.accounting.ledger_modules.ledger_grouping import (
    fetch_grouped_trades,
    fetch_trade_group_by_id,
    collapse_expand_group,
)
from tbot_bot.accounting.ledger_modules.ledger_query import search_trades

# Useful for display sanity (not mutating here)
from tbot_bot.accounting.ledger_modules.ledger_balance import calculate_running_balances  # noqa: F401

ledger_web = Blueprint("ledger_web", __name__)

BOT_STATE_PATH = Path(__file__).resolve().parents[2] / "tbot_bot" / "control" / "bot_state.txt"
INITIALIZE_STATES = ("initialize", "provisioning", "bootstrapping")


def get_current_bot_state():
    try:
        with open(BOT_STATE_PATH, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return "unknown"


def provisioning_guard():
    state = get_current_bot_state()
    if state in INITIALIZE_STATES:
        flash("Provisioning not complete. Ledger access is unavailable.")
        return True
    return False


def identity_guard():
    try:
        bot_identity_string = load_bot_identity()
        if not bot_identity_string or not get_bot_identity_string_regex().match(bot_identity_string):
            flash("Bot identity not available, please complete configuration.")
            return True
        validate_bot_identity(bot_identity_string)
        return False
    except Exception:
        flash("Bot identity not available, please complete configuration.")
        return True


def _is_display_entry(entry):
    # True if at least one primary display field is present/non-empty
    return bool(
        (entry.get("symbol") and str(entry.get("symbol")).strip())
        or (entry.get("datetime_utc") and str(entry.get("datetime_utc")).strip())
        or (entry.get("action") and str(entry.get("action")).strip())
        or (entry.get("price") not in (None, "", "None"))
        or (entry.get("quantity") not in (None, "", "None"))
        or (entry.get("total_value") not in (None, "", "None"))
    )


@ledger_web.route('/ledger/reconcile', methods=['GET', 'POST'])
def ledger_reconcile():
    error = None
    entries = []
    balances = {}
    coa_accounts = []
    if provisioning_guard() or identity_guard():
        return render_template(
            'ledger.html',
            entries=entries,
            error="Ledger access not available (provisioning or identity incomplete).",
            balances=balances,
            coa_accounts=coa_accounts,
        )
    try:
        from tbot_bot.accounting.ledger_modules.ledger_balance import calculate_account_balances
        balances = calculate_account_balances()

        coa_data = load_coa_metadata_and_accounts()
        coa_accounts = coa_data.get("accounts_flat", [])  # list of (code, name)

        # Use grouped view by default (collapsed)
        entries = fetch_grouped_trades()
        entries = [e for e in entries if _is_display_entry(e)]

        # Helpful trace for troubleshooting UI emptiness
        print("LEDGER ENTRIES SERVED (count={}):".format(len(entries)))
        if entries:
            print("LEDGER SAMPLE (first entry):", entries[0])

    except FileNotFoundError:
        error = "Ledger database or table not found. Please initialize via admin tools."
        entries = []
        balances = {}
        coa_accounts = []
    except Exception as e:
        error = f"Ledger error: {e}"
        traceback.print_exc()
        entries = []
        balances = {}
        coa_accounts = []
    return render_template('ledger.html', entries=entries, error=error, balances=balances, coa_accounts=coa_accounts)


@ledger_web.route('/ledger/group/<group_id>', methods=['GET'])
def ledger_group_detail(group_id):
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    try:
        group = fetch_trade_group_by_id(group_id)
        return jsonify(group)
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@ledger_web.route('/ledger/collapse_expand/<group_id>', methods=['POST'])
def ledger_collapse_expand(group_id):
    if provisioning_guard() or identity_guard():
        return jsonify({"ok": False, "error": "Not permitted"}), 403
    try:
        # Accept optional explicit state from the client.
        # convention: collapsed_state = 1 means "collapsed", 0 means "expanded"
        data = request.get_json(silent=True) or {}
        collapsed_state = data.get("collapsed_state", None)
        if collapsed_state is not None:
            # normalize to 0/1
            collapsed_state = 1 if str(collapsed_state).lower() in ("1", "true", "yes") else 0
            result = collapse_expand_group(group_id, collapsed_state=collapsed_state)
        else:
            # no state provided -> toggle
            result = collapse_expand_group(group_id)

        return jsonify({"ok": True, "result": bool(result), "collapsed_state": collapsed_state})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@ledger_web.route('/ledger/collapse_all', methods=['POST'])
def ledger_collapse_all():
    """
    Collapse or expand ALL groups in one shot.
    Accepts JSON in any of these shapes:
      {"collapse": true}          -> collapse all
      {"collapse": false}         -> expand all
      {"collapsed_state": 1|0}    -> 1 collapse, 0 expand
      {"expanded": true|false}    -> inverse of collapsed_state
    """
    if provisioning_guard() or identity_guard():
        return jsonify({"ok": False, "error": "Not permitted"}), 403
    try:
        data = request.get_json(silent=True) or {}
        if "collapse" in data:
            collapsed_state = 1 if bool(data["collapse"]) else 0
        elif "collapsed_state" in data:
            collapsed_state = 1 if str(data["collapsed_state"]).lower() in ("1", "true", "yes") else 0
        elif "expanded" in data:
            collapsed_state = 0 if bool(data["expanded"]) else 1
        else:
            return jsonify({"ok": False, "error": "missing collapse/expanded flag"}), 400

        # Fetch current groups (collapsed view is fine; we only need IDs)
        groups = fetch_grouped_trades(collapse=True, limit=10000)
        group_ids = [g.get("group_id") or g.get("trade_id") for g in groups if g]
        group_ids = [gid for gid in group_ids if gid]

        changed = 0
        for gid in group_ids:
            try:
                collapse_expand_group(gid, collapsed_state=collapsed_state)
                changed += 1
            except Exception:
                # keep going; report partial success
                traceback.print_exc()

        return jsonify({"ok": True, "collapsed_state": collapsed_state, "count": changed})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500


@ledger_web.route('/ledger/search', methods=['GET'])
def ledger_search():
    if provisioning_guard() or identity_guard():
        return jsonify({"error": "Not permitted"}), 403
    query = request.args.get('q', '').strip()
    sort_by = request.args.get('sort_by', 'datetime_utc')
    sort_desc = request.args.get('sort_desc', '1') == '1'
    try:
        results = search_trades(search_term=query, sort_by=sort_by, sort_desc=sort_desc)
        results = [e for e in results if _is_display_entry(e)]
        return jsonify(results)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@ledger_web.route('/ledger/resolve/<int:entry_id>', methods=['POST'])
def resolve_ledger_entry(entry_id):
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    from tbot_bot.accounting.ledger import mark_entry_resolved
    mark_entry_resolved(entry_id)
    flash('Entry marked as resolved.')
    return redirect(url_for('ledger_web.ledger_reconcile'))


@ledger_web.route('/ledger/add', methods=['POST'])
def add_ledger_entry_route():
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    from tbot_bot.accounting.ledger import post_ledger_entries_double_entry

    form = request.form
    bot_identity = load_bot_identity()
    entity_code, jurisdiction_code, broker, bot_id = bot_identity.split("_")
    current_user = get_current_user()
    config = get_bot_config()

    def _num(val, default=None):
        try:
            return float(val)
        except Exception:
            return default

    entry_data = {
        "datetime_utc": form.get("datetime_utc"),
        "symbol": form.get("symbol"),
        "action": form.get("action"),
        "quantity": _num(form.get("quantity")),
        "price": _num(form.get("price")),
        "total_value": _num(form.get("total_value")),
        "fee": _num(form.get("fee"), 0.0),
        "account": form.get("account"),
        "strategy": form.get("strategy"),
        "trade_id": form.get("trade_id"),
        "tags": form.get("tags"),
        "notes": form.get("notes"),
        "jurisdiction_code": jurisdiction_code,
        "entity_code": entity_code,
        "language": config.get("LANGUAGE_CODE", "en"),
        "created_by": getattr(current_user, "username", None) or (current_user if current_user else "system"),
        "updated_by": getattr(current_user, "username", None) or (current_user if current_user else "system"),
        "approved_by": getattr(current_user, "username", None) or (current_user if current_user else "system"),
        "approval_status": "pending",
        "gdpr_compliant": True,
        "ccpa_compliant": True,
        "pipeda_compliant": True,
        "hipaa_sensitive": False,
        "iso27001_tag": "",
        "soc2_type": "",
    }
    try:
        # amount sign/side handled inside double-entry mapping,
        # but provide a sane numeric default for pre-validation.
        entry_data["amount"] = _num(entry_data.get("total_value"), 0.0) or 0.0
        post_ledger_entries_double_entry([entry_data])
        flash('Ledger entry added (double-entry compliant).')
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed: trades.trade_id" in str(e):
            flash("Trade ID already exists. Please use a unique Trade ID.", "error")
        else:
            flash(f"Ledger DB error: {e}", "error")
    except Exception as e:
        traceback.print_exc()
        flash(f"Ledger error: {e}", "error")
    return redirect(url_for('ledger_web.ledger_reconcile'))


@ledger_web.route('/ledger/edit/<int:entry_id>', methods=['POST'])
def edit_ledger_entry_route(entry_id):
    """
    Full edit (legacy) — keeps behavior for forms that post many fields.
    If you only want to change the COA account, use /ledger/update_account/<id>.
    """
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    from tbot_bot.accounting.ledger import edit_ledger_entry

    form = request.form
    bot_identity = load_bot_identity()
    entity_code, jurisdiction_code, broker, bot_id = bot_identity.split("_")
    current_user = get_current_user()
    config = get_bot_config()

    def _num(val, default=None):
        try:
            return float(val)
        except Exception:
            return default

    updated_data = {
        "datetime_utc": form.get("datetime_utc"),
        "symbol": form.get("symbol"),
        "action": form.get("action"),
        "quantity": _num(form.get("quantity")),
        "price": _num(form.get("price")),
        "total_value": _num(form.get("total_value")),
        "fee": _num(form.get("fee"), 0.0),
        "account": form.get("account"),
        "strategy": form.get("strategy"),
        "trade_id": form.get("trade_id"),
        "tags": form.get("tags"),
        "notes": form.get("notes"),
        "jurisdiction_code": jurisdiction_code,
        "entity_code": entity_code,
        "language": config.get("LANGUAGE_CODE", "en"),
        "updated_by": getattr(current_user, "username", None) or (current_user if current_user else "system"),
        "approval_status": form.get("approval_status", "pending"),
        "gdpr_compliant": True,
        "ccpa_compliant": True,
        "pipeda_compliant": True,
        "hipaa_sensitive": False,
        "iso27001_tag": "",
        "soc2_type": "",
    }
    try:
        updated_data["amount"] = _num(updated_data.get("total_value"), 0.0) or 0.0
        edit_ledger_entry(entry_id, updated_data)
        flash('Ledger entry updated.')
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed: trades.trade_id" in str(e):
            flash("Trade ID already exists. Please use a unique Trade ID.", "error")
        else:
            flash(f"Ledger DB error: {e}", "error")
    except Exception as e:
        traceback.print_exc()
        flash(f"Ledger error: {e}", "error")
    return redirect(url_for('ledger_web.ledger_reconcile'))


# ---------- NEW: minimal, safe COA account updater (single-row or whole-group) ----------

def _valid_account_code(code: str) -> bool:
    if not code:
        return False
    try:
        coa = load_coa_metadata_and_accounts()
        valid_codes = {c for c, _n in (coa.get("accounts_flat", []) or [])}
        return code in valid_codes
    except Exception:
        return False


@ledger_web.route('/ledger/update_account/<int:entry_id>', methods=['POST'])
def update_ledger_account_route(entry_id: int):
    """
    Update only the COA account (and optionally strategy) for a single ledger row.
    Optional form fields:
      - account (required)
      - strategy (optional)
      - apply_to_group: "1" to apply to all rows with the same group_id
    """
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))

    account = (request.form.get("account") or "").strip()
    strategy = (request.form.get("strategy") or "").strip() or None
    apply_to_group = str(request.form.get("apply_to_group", "0")).lower() in ("1", "true", "yes")

    if not _valid_account_code(account):
        flash("Invalid account code.", "error")
        return redirect(url_for('ledger_web.ledger_reconcile'))

    # Locate DB
    bot_identity = load_bot_identity()
    e, j, b, bot_id = bot_identity.split("_")
    db_path = resolve_ledger_db_path(e, j, b, bot_id)

    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT id, group_id FROM trades WHERE id = ?", (entry_id,)).fetchone()
            if not row:
                flash("Entry not found.", "error")
                return redirect(url_for('ledger_web.ledger_reconcile'))

            if apply_to_group and row["group_id"]:
                params = [account]
                sql = "UPDATE trades SET account = ?"
                if strategy is not None:
                    sql += ", strategy = ?"
                    params.append(strategy)
                sql += " WHERE group_id = ?"
                params.append(row["group_id"])
                conn.execute(sql, tuple(params))
            else:
                params = [account]
                sql = "UPDATE trades SET account = ?"
                if strategy is not None:
                    sql += ", strategy = ?"
                    params.append(strategy)
                sql += " WHERE id = ?"
                params.append(entry_id)
                conn.execute(sql, tuple(params))
            conn.commit()

        flash("Account updated." + (" (Applied to group.)" if apply_to_group else ""))
    except Exception as e:
        traceback.print_exc()
        flash(f"Failed to update account: {e}", "error")

    return redirect(url_for('ledger_web.ledger_reconcile'))


@ledger_web.route('/ledger/update_account_json', methods=['POST'])
def update_ledger_account_json():
    """
    JSON variant for XHR updates.
    Body: {"entry_id": 123, "account": "Assets:Cash", "strategy":"open", "apply_to_group": true}
    """
    if provisioning_guard() or identity_guard():
        return jsonify({"ok": False, "error": "Not permitted"}), 403

    data = request.get_json(silent=True) or {}
    try:
        entry_id = int(data.get("entry_id"))
    except Exception:
        return jsonify({"ok": False, "error": "missing/invalid entry_id"}), 400

    account = (data.get("account") or "").strip()
    strategy = (data.get("strategy") or "").strip() or None
    apply_to_group = bool(data.get("apply_to_group", False))

    if not _valid_account_code(account):
        return jsonify({"ok": False, "error": "invalid account code"}), 400

    # Locate DB
    bot_identity = load_bot_identity()
    e, j, b, bot_id = bot_identity.split("_")
    db_path = resolve_ledger_db_path(e, j, b, bot_id)

    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT id, group_id FROM trades WHERE id = ?", (entry_id,)).fetchone()
            if not row:
                return jsonify({"ok": False, "error": "entry not found"}), 404

            if apply_to_group and row["group_id"]:
                params = [account]
                sql = "UPDATE trades SET account = ?"
                if strategy is not None:
                    sql += ", strategy = ?"
                    params.append(strategy)
                sql += " WHERE group_id = ?"
                params.append(row["group_id"])
                conn.execute(sql, tuple(params))
            else:
                params = [account]
                sql = "UPDATE trades SET account = ?"
                if strategy is not None:
                    sql += ", strategy = ?"
                    params.append(strategy)
                sql += " WHERE id = ?"
                params.append(entry_id)
                conn.execute(sql, tuple(params))
            conn.commit()

        return jsonify({"ok": True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500


@ledger_web.route('/ledger/delete/<int:entry_id>', methods=['POST'])
def delete_ledger_entry_route(entry_id):
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    from tbot_bot.accounting.ledger import delete_ledger_entry
    delete_ledger_entry(entry_id)
    flash('Ledger entry deleted.')
    return redirect(url_for('ledger_web.ledger_reconcile'))


@ledger_web.route('/ledger/sync', methods=['POST'])
def ledger_sync():
    """
    Kicks off broker->ledger sync. Adds verbose traces so we can see when it ran and what it did.
    """
    if provisioning_guard() or identity_guard():
        return redirect(url_for('main.root_router'))
    try:
        print("[WEB] /ledger/sync: invoked")
        from tbot_bot.accounting.ledger import sync_broker_ledger
        sync_broker_ledger()
        # quick post-check for sanity & flash useful info
        try:
            bot_identity = load_bot_identity()
            e, j, b, bot_id = bot_identity.split("_")
            db_path = resolve_ledger_db_path(e, j, b, bot_id)
            with sqlite3.connect(db_path) as conn:
                total = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
                empty_groups = conn.execute("SELECT COUNT(*) FROM trades WHERE group_id IS NULL OR group_id=''").fetchone()[0]
            print(f"[WEB] /ledger/sync: completed OK - rows={total}, empty_group_id={empty_groups}")
            if empty_groups:
                flash(f"Broker ledger synced. {total} rows present; {empty_groups} missing group_id.")
            else:
                flash(f"Broker ledger synced successfully. {total} rows present.")
        except Exception as e2:
            print("[WEB] /ledger/sync: post-check failed:", repr(e2))
            flash("Broker ledger synced (post-check failed).")
    except Exception as e:
        traceback.print_exc()
        print("[WEB] /ledger/sync: ERROR:", repr(e))
        flash(f"Broker ledger sync failed: {e}")
    return redirect(url_for('ledger_web.ledger_reconcile'))
